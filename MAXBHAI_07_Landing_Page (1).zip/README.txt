MAXBHAI_07 Landing Page
=======================

Files:
- index.html  : page structure and text
- style.css   : responsive dark theme design
- script.js   : mobile menu and small interactions

Before publishing:
1. Open index.html in a code editor.
2. Find every occurrence of https://t.me/YOUR_TELEGRAM_USERNAME in index.html.
3. Replace it with your real Telegram group/channel URL.
4. Update the page text to match your community accurately.
5. Upload all three files to a static hosting service (for example GitHub Pages, Netlify, or your own web hosting).

This is a starter template, not a copy of the referenced site's original source.
